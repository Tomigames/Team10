import React, { useEffect, useState, useCallback, useContext } from 'react';
import axios from 'axios';
import './Course.css';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronUp } from 'lucide-react'; // For the dropdown icon
import { UserContext } from './UserContext'; // Import the context

// Helper function to determine the grade color
const getGradeColor = (grade) => {
    if (grade >= 90) return 'green';
    if (grade >= 80) return 'yellow';
    if (grade >= 70) return 'red';
    return 'gray';
};

// Sub-component for displaying individual assessments
const AssessmentItem = ({ assessment }) => (
    <div className="assessment-item">
        <span className="assessment-name">{assessment.AssessmentName}:</span>
        <span className="assessment-grade">
            {assessment.IndividualGrade !== null ? `${assessment.IndividualGrade}%` : 'N/A'}
        </span>
    </div>
);

// Sub-component for displaying a weight section
const WeightSection = ({ weightType, assessments, weightPercentage }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="weight-section">
            <div
                className="weight-header"
                onClick={() => setIsOpen(!isOpen)}
            >
                <div className='weight-header-content'>
                    <span className="weight-type">{weightType} ({weightPercentage}%)</span>
                    {isOpen ? (
                        <ChevronUp className="dropdown-icon" size={16} />
                    ) : (
                        <ChevronDown className="dropdown-icon" size={16} />
                    )}
                </div>
            </div>
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="assessment-list"
                    >
                        {assessments.map((assessment) => (
                            <AssessmentItem key={assessment.AssessmentID} assessment={assessment} />
                        ))}
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

// Component for displaying a single course
const CourseItem = ({ course, onDelete, onEdit }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const [assessments, setAssessments] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const { userId } = useContext(UserContext);

    // Fetch assessments when the course is expanded
    useEffect(() => {
        if (isExpanded && userId) {
            setLoading(true);
            setError(null);
            axios.get(`http://localhost:8081/assessments/${course.CourseID}?userId=${userId}`)
                .then(res => {
                    setAssessments(res.data);
                })
                .catch(err => {
                    setError(err.message || 'Failed to fetch assessments');
                })
                .finally(() => setLoading(false));
        } else {
            setAssessments([]); // Clear assessments when collapsed.  Important for performance.
        }
    }, [isExpanded, course.CourseID, userId]);

    // Function to group assessments by weight
    const groupAssessmentsByWeight = useCallback((assessments) => {
        const grouped = {};
        assessments.forEach(assessment => {
            if (!grouped[assessment.WeightID]) {
                grouped[assessment.WeightID] = {
                    weightType: assessment.AssessmentType,
                    weightPercentage: assessment.WeightPercentage,
                    assessments: []
                };
            }
            grouped[assessment.WeightID].assessments.push(assessment);
        });
        return Object.values(grouped);
    }, []);

    const groupedAssessments = groupAssessmentsByWeight(assessments);

    return (
        <div className="course-item">
            <div
                className="course-header"
                onClick={() => setIsExpanded(!isExpanded)}
            >
                <div className="course-details">
                    <div className="course-name">{course.CourseName}</div>
                    <div className="instructor">{course.Instructor}</div>
                </div>
                <div className="header-actions">
                    <button className="edit-button" onClick={() => onEdit(course.CourseID)}>Edit</button>
                    <button
                        className="delete-button"
                        onClick={() => {
                            onDelete(course.UserID, Number(course.CourseID));
                        }}
                    >
                        Delete
                    </button>
                </div>
                <div className="grade" style={{ backgroundColor: getGradeColor(course.OverallGrade) }}>
                    {course.OverallGrade}
                </div>

                {isExpanded ? (
                    <ChevronUp className="expand-icon" size={20} />
                ) : (
                    <ChevronDown className="expand-icon" size={20} />
                )}
            </div>
            <AnimatePresence>
                {isExpanded && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="course-dropdown"
                    >
                        {loading ? (
                            <div className="loading">Loading Assessments...</div>
                        ) : error ? (
                            <div className="error">{error}</div>
                        ) : groupedAssessments.length > 0 ? (
                            <div className="weight-sections-container">
                                {groupedAssessments.map((weightGroup) => (
                                    <WeightSection
                                        key={weightGroup.weightType}
                                        weightType={weightGroup.weightType}
                                        assessments={weightGroup.assessments}
                                        weightPercentage={weightGroup.weightPercentage}
                                    />
                                ))}
                            </div>
                        ) : (
                            <div className="no-assessments">No assessments for this course.</div>
                        )}
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

function Course() {
    const [courses, setCourses] = useState([]);
    const [selectedSemester, setSelectedSemester] = useState('All');
    const [isSemesterDropdownOpen, setIsSemesterDropdownOpen] = useState(false);
    const [selectedYear, setSelectedYear] = useState('All');
    const [isYearDropdownOpen, setIsYearDropdownOpen] = useState(false);
    const navigate = useNavigate();
    const { userId } = useContext(UserContext); // Access the userId from the context


    useEffect(() => {
        if (userId) { // Only fetch courses if userId is available
            fetchCourses(selectedSemester, selectedYear, userId);
        }
    }, [selectedSemester, selectedYear, userId]);

    const fetchCourses = (semester = 'All', year = 'All', currentUserId) => {
        let apiUrl = 'http://localhost:8081/';
        const queryParams = [];
        if (semester !== 'All') {
            queryParams.push(`semester=${semester}`);
        }
        if (year !== 'All') {
            queryParams.push(`year=${year}`);
        }
        if (currentUserId) {
            queryParams.push(`userId=${currentUserId}`); // Send UserID to the backend
        }

        if (queryParams.length > 0) {
            apiUrl += `?${queryParams.join('&')}`;
        }

        axios.get(apiUrl)
            .then(res => setCourses(res.data))
            .catch(err => console.log(err));
    };

    const handleDelete = (userIdToDelete, courseId) => {
        axios.delete(`http://localhost:8081/course/${courseId}`, {
            data: { UserID: userId },
        })
            .then(() => {
                fetchCourses(selectedSemester, selectedYear, userId);
            })
            .catch(err => console.error("Error deleting course:", err));
    };

    const handleEdit = (courseId) => {
        navigate(`/edit/${courseId}`);
    };

    // Semester dropdown functions
    const toggleSemesterDropdown = () => {
        setIsSemesterDropdownOpen(!isSemesterDropdownOpen);
    };

    const handleSemesterSelect = (semester) => {
        setSelectedSemester(semester);
        fetchCourses(semester, selectedYear, userId);
        setIsSemesterDropdownOpen(false);
    };

    const getUniqueSemesters = () => {
        const allPossibleSemesters = ['All', 'Spring', 'Fall'];
        const fetchedSemesters = new Set(courses.map(course => course.Semester));
        const uniqueSemesters = [...allPossibleSemesters];
        fetchedSemesters.forEach(semester => {
            if (!uniqueSemesters.includes(semester)) {
                uniqueSemesters.push(semester);
            }
        });
        return uniqueSemesters;
    };

    // Year dropdown functions
    const toggleYearDropdown = () => {
        setIsYearDropdownOpen(!isYearDropdownOpen);
    };

    const handleYearSelect = (year) => {
        setSelectedYear(year);
        fetchCourses(semester, selectedYear, userId);
        setIsYearDropdownOpen(false);
    };

    const getUniqueYears = () => {
      const allPossibleYears = ['All', '2023', '2024', '2025']; // Define the years you want to show
      const fetchedYears = new Set(courses.map(course => course.Year));
      const uniqueYears = [...allPossibleYears];
      fetchedYears.forEach(year => {
          if (!uniqueYears.includes(year.toString())) {
              uniqueYears.push(year.toString());
          }
      });
      return uniqueYears;
  };

    return (
        <div className="course-container">
            <div className="header">
                <div className={`semester-dropdown ${isSemesterDropdownOpen ? 'open' : ''}`}>
                    <button className="semester-button" onClick={toggleSemesterDropdown}>
                        {selectedSemester} <span className="dropdown-icon">{isSemesterDropdownOpen ? '^' : 'v'}</span>
                    </button>
                    {isSemesterDropdownOpen && (
                        <div className="dropdown-content">
                            {getUniqueSemesters().map(semester => (
                                <button
                                    key={semester}
                                    onClick={() => handleSemesterSelect(semester)}
                                    className={semester === selectedSemester ? 'active' : ''}
                                >
                                    {semester}
                                </button>
                            ))}
                        </div>
                    )}
                </div>
                <div className={`semester-download ${isYearDropdownOpen ? 'open' : ''}`}>
                    <button className="download-button" onClick={toggleYearDropdown}>
                        {selectedYear} <span className="dropdown-icon">{isYearDropdownOpen ? '^' : 'v'}</span>
                    </button>
                    {isYearDropdownOpen && (
                        <div className="dropdown-content">
                            {getUniqueYears().map(year => (
                                <button
                                    key={year}
                                    onClick={() => handleYearSelect(year)}
                                    className={year === selectedYear ? 'active' : ''}
                                >
                                    {year}
                                </button>
                            ))}
                        </div>
                    )}
                </div>
                <button className="add-button" onClick={() => navigate('/create')}>Add Course</button>
            </div>

            <div className="course-list">
                {courses.map((course) => (
                    <CourseItem
                        key={course.CourseID}
                        course={course}
                        onDelete={handleDelete}
                        onEdit={handleEdit}
                    />
                ))}
            </div>
        </div>
    );
}

export default Course;