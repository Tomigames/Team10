// App.js
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Course from './Course';
import CreateCourse from './CreateCourse';
import EditCourse from './EditCourse';
import LoginPage from './LoginPage';
import HomePage from './HomePage';
import { UserProvider, UserContext } from './UserContext'; // Import UserProvider and Context
import React, { useContext } from 'react';

// Protected Route component to ensure user is logged in
const ProtectedRoute = ({ children }) => {
  const { userId } = useContext(UserContext);
  return userId ? children : <Navigate to="/login" />;
};

function App() {
  return (
    <div className="App">
      <UserProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/home" element={<ProtectedRoute><HomePage /></ProtectedRoute>} />
            <Route path="/courses" element={<ProtectedRoute><Course /></ProtectedRoute>} />
            <Route path="/create" element={<ProtectedRoute><CreateCourse /></ProtectedRoute>} />
            <Route path="/edit/:id" element={<ProtectedRoute><EditCourse /></ProtectedRoute>} />
            <Route path="/" element={<Navigate to="/login" />} /> {/* Redirect root to login */}
          </Routes>
        </BrowserRouter>
      </UserProvider>
    </div>
  );
}

export default App;